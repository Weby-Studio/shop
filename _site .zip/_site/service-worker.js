                        importScripts("/assets/js/workbox-v5.1.4/workbox-sw.js");
            workbox.setConfig({modulePathPrefix: "/assets/js/workbox-v5.1.4"});

            self.__precacheManifest = [{"url":"/index.html","revision":"6fe4cb05446a1a0235f551cbfe72f9f4"},{"url":"/manifest.json","revision":"65ff66b7db1d56bece111d69bfa72023"},{"url":"/assets/js/bwk-store.js","revision":"d41d8cd98f00b204e9800998ecf8427e"},{"url":"/assets/css/styles.css","revision":"d5b300e61785036f8dc289562a2c3015"},{"url":"/assets/css/code-highlight.css","revision":"962cead98433fe5d77f6287a95354295"},{"url":"/assets/css/theme-dark.css","revision":"d01dd1d4da939804719fc1701cbeb8f4"},{"url":"/assets/css/theme-light.css","revision":"e30f74e5ec0b3105723d66ecaf037ce8"},{"url":"/assets/css/style.css","revision":"0c12d00cc93c2b64eb4cccb3d36df8fd"},{"url":"/assets/uploads/bwk_bot.png","revision":"43ecd02e10c6fc7fad6e6cd2e033362c"},{"url":"/assets/uploads/android-chrome-512x512.png","revision":"9dee9d766bc502a8ea2116ffeb826495"},{"url":"/assets/uploads/loader.mov","revision":"084a9a7de5a4da1e082d6a21ddef7729"},{"url":"/google04b63ea86a793e7b.html","revision":"bfc8ca58267cacd7574a31d07141ab91"},{"url":"/products/ttttttt/index.html","revision":"429ab909fb9005b4716a68d8247e1ce9"},{"url":"/products/ttttttt2/index.html","revision":"94a8d93f9ce1d48455cf29b558264045"},{"url":"/authors/ted/index.html","revision":"d60935218f9f7bedabf66f46dacf1548"},{"url":"/authors/boris/index.html","revision":"39d24dd211d3eb6f5c6147fbd9638265"},{"url":"/authors/jill/index.html","revision":"82ac48805971d73a131c95577e66dfbf"},{"url":"/authors/bullwinkle/index.html","revision":"f99e8edd1c6d81c767060705ec02c60d"},{"url":"/authors/vasja/index.html","revision":"b852ad4b658fd884aabc35b47f8728a2"},{"url":"/admin/index.html","revision":"8f3719d6d546816bb2afdc2f44c98c13"},{"url":"/blog/p4/index.html","revision":"fe587b8f8032a4bb2ef0b18cca7f9771"},{"url":"/blog/p3/index.html","revision":"8558d3eb1adac2c46bc0cd491a8db6ff"},{"url":"/blog/p2/index.html","revision":"66b5010516918dea5a8210d8df9d4dd9"},{"url":"/blog/p5/index.html","revision":"2cc54eff02a03002840a46904c3f5af0"},{"url":"/blog/index.html","revision":"c8ed6a3b931d101559dc21c43a8a7c25"},{"url":"/blog/2021/04/20/your-filename/index.html","revision":"14947faaeee2c3e490993d3bb53720f8"},{"url":"/blog/uncategorized/2021/03/05/title-1/index.html","revision":"4f0d07f2b022c2683f6575f95ced31b2"},{"url":"/blog/uncategorized/2021/03/05/title/index.html","revision":"af435789802685824685af4d2bd78ea7"},{"url":"/blog/uncategorized/2021/03/05/new-two/index.html","revision":"8154ed5622da51d40179b51035810cea"},{"url":"/blog/uncategorized/2021/03/05/new-one/index.html","revision":"ace3d7ff8d04f57978bea65c5236204f"},{"url":"/blog/uncategorized/2021/04/20/test-one/index.html","revision":"fdb894745c73ffb3b0b20a5778075437"},{"url":"/blog/uncategorized/2021/04/21/test/index.html","revision":"3d18d8b70a7af4b617c2884c6c226ff9"},{"url":"/blog/cars/2019/08/20/porshe/index.html","revision":"0ca7d55f574640753b90b591847c3a8c"},{"url":"/blog/cars/2019/08/21/bmw/index.html","revision":"b1388497fd2ef506e565f9150352200f"},{"url":"/blog/cars/2019/08/22/audi/index.html","revision":"e7cb13f8e130bbaa3dfb337ed2ebeb43"},{"url":"/blog/fruits/2021/03/05/bananas/index.html","revision":"59388a4511ecd0e8a5c66d9b71b54e4e"},{"url":"/blog/fruits/2021/03/05/kiwifruit/index.html","revision":"e952facbad8ab6f1972b5dd7b9cd049c"},{"url":"/blog/fruits/2021/03/05/apples/index.html","revision":"1505fba8a9ec7eba2e145e0dea4be496"},{"url":"/notes/note-2/index.html","revision":"81799248730537edf4920ac8bf6f4d4b"},{"url":"/notes/note-1/index.html","revision":"5afd824e721cbaa1a82f0293d8d34696"},{"url":"/pages/products/index.html","revision":"e2ded2138431ce45f4af59fd1930579f"},{"url":"/pages/authors/index.html","revision":"6754771a65915fbff0444c5c6b562aed"},{"url":"/pages/experiments/index.html","revision":"716d130b5ff7445d89b3559b8e758794"},{"url":"/pages/about/index.html","revision":"9d75abe196e03c21b060f6da4f5efd88"},{"url":"/pages/tags/index.html","revision":"b6070fc8507dc20fbfb14f38eaeb2756"},{"url":"/pages/notes/index.html","revision":"09a9b40a7560af0ad70a6f5a508a304d"},{"url":"/pages/collections/index.html","revision":"77118eee0fdd2cff022ef63f9c2c08f0"},{"url":"/pages/categories/index.html","revision":"e153d8ad59898396aa22ec8923354bd2"},{"url":"/pages/system-info/index.html","revision":"0cb6c9ebaac00fe0515f22cc132758e2"},{"url":"/blog/uncategorized/2021/04/21/test/","revision":"d9ad6ccb6cac0e4257a3775ea4efbe92"},{"url":"/blog/2021/04/20/your-filename/","revision":"533ca5f6ffd00bf4d8a4c2afa3adb02b"},{"url":"/blog/uncategorized/2021/04/20/test-one/","revision":"ad21e4303b9fe5be19ba9d79fbd66496"},{"url":"/blog/uncategorized/2021/03/05/title-1/","revision":"0d0ecf7eb470f3a173879ac57fa45fc9"},{"url":"/blog/uncategorized/2021/03/05/title/","revision":"013d89ac433da09856b1fe8f514bc793"},{"url":"/blog/uncategorized/2021/03/05/new-two/","revision":"f0ab4e5cb58661860729e20e4396607d"},{"url":"/blog/uncategorized/2021/03/05/new-one/","revision":"b0e0ce431904b7746e6de1efe1268567"},{"url":"/blog/fruits/2021/03/05/kiwifruit/","revision":"29d625d5d591e73756e2545cb4a4befd"},{"url":"/blog/fruits/2021/03/05/bananas/","revision":"a07079e635b85dcb48ddf3507df2e167"},{"url":"/blog/fruits/2021/03/05/apples/","revision":"c19e0def4d5889455cc0b90670632e9f"}];
            // service-worker.js

// set names for both precache & runtime cache
workbox.core.setCacheNameDetails({
    prefix: 'bullwinkle_space',
    suffix: 'v1.0',
    precache: 'precache',
    runtime: 'runtime-cache'
});

// let Service Worker take control of pages ASAP
workbox.core.skipWaiting();
workbox.core.clientsClaim();

// let Workbox handle our precache list
workbox.precaching.precacheAndRoute(self.__precacheManifest);

// use `NetworkFirst` strategy for html
workbox.routing.registerRoute(
    /\.html$/,
    new workbox.strategies.NetworkFirst()
);

// use `NetworkFirst` strategy for css and js
workbox.routing.registerRoute(
    /\.(?:js|css)$/,
    new workbox.strategies.NetworkFirst()
);

// use `CacheFirst` strategy for images
workbox.routing.registerRoute(
    /assets\/(images|favicon|icons)/,
    new workbox.strategies.CacheFirst()
);

// use `StaleWhileRevalidate` third party files
workbox.routing.registerRoute(
    /^https?:\/\/media.githubusercontent.com/,
    new workbox.strategies.StaleWhileRevalidate()
);

