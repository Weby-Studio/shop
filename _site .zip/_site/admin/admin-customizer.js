import CMS from 'netlify-cms-app';
// Initialize the CMS object
CMS.init();

console.log('CMS INIT', CMS);
// Now the registry is available via the CMS object.
//CMS.registerPreviewTemplate('my-template', MyTemplate)
