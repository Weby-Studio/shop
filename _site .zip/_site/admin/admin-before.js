console.log('admin-before.js loaded')
