console.log('admin-after.js loaded');
